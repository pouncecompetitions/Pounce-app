plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---- Pounce settings you may want to change ----
val siteUrl = "https://pouncecompetitions.co.uk/?appmode=on"
// Paste your OneSignal App ID between the quotes to switch on push notifications.
val oneSignalAppId = ""
// -------------------------------------------------

android {
    namespace = "uk.co.pouncecompetitions.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "uk.co.pouncecompetitions.app"
        minSdk = 26
        targetSdk = 35
        // Each GitHub build gets a higher number so updates install over the old app.
        val build = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = build
        versionName = "1.0.$build"
        buildConfigField("String", "SITE_URL", "\"$siteUrl\"")
        buildConfigField("String", "ONESIGNAL_APP_ID", "\"$oneSignalAppId\"")
    }

    // The signing key lives at signing/pounce.jks; its password comes from the
    // KEYSTORE_PASSWORD secret on GitHub. Updates MUST use the same key.
    val keystore = rootProject.file("signing/pounce.jks")
    val keystorePassword = System.getenv("KEYSTORE_PASSWORD")
    val canSign = keystore.exists() && !keystorePassword.isNullOrEmpty()

    signingConfigs {
        create("release") {
            if (canSign) {
                storeFile = keystore
                storePassword = keystorePassword
                keyAlias = "pounce"
                keyPassword = keystorePassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (canSign) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    buildFeatures {
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("com.onesignal:OneSignal:[5.1.6, 5.99.99]")
}
