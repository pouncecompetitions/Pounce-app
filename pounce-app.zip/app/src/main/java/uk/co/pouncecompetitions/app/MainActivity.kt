package uk.co.pouncecompetitions.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.onesignal.OneSignal
import com.onesignal.notifications.INotificationClickEvent
import com.onesignal.notifications.INotificationClickListener
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var offline: View

    private var keepSplash = true
    private var hadError = false
    private var lastUrl: String = BuildConfig.SITE_URL

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { keepSplash }
        // Never keep the splash up for more than 4 seconds.
        Handler(Looper.getMainLooper()).postDelayed({ keepSplash = false }, 4000)

        setContentView(R.layout.activity_main)
        val root = findViewById<View>(R.id.root)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = false
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        webView = findViewById(R.id.webview)
        refresh = findViewById(R.id.refresh)
        offline = findViewById(R.id.offline)
        findViewById<Button>(R.id.retry).setOnClickListener { retry() }

        setUpWebView()

        refresh.setColorSchemeColors(Color.parseColor("#8A00FF"))
        refresh.setProgressBackgroundColorSchemeColor(Color.parseColor("#15121B"))
        refresh.setOnRefreshListener { webView.reload() }
        refresh.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }

        onBackPressedDispatcher.addCallback(this) {
            if (webView.canGoBack()) {
                webView.goBack()
            } else {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            load(appUrl(intent?.data) ?: BuildConfig.SITE_URL)
        }

        setUpPush()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setUpWebView() {
        webView.setBackgroundColor(Color.BLACK)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false // lets card videos autoplay muted
            setSupportMultipleWindows(false)          // target="_blank" opens in the app
            // Tells the website this is the Pounce app.
            userAgentString = "$userAgentString PounceApp/${BuildConfig.VERSION_NAME} (Android)"
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true) // needed for card payments / 3-D Secure
        }
        webView.addJavascriptInterface(PounceBridge(), "PounceApp")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                return when (uri.scheme?.lowercase()) {
                    "http", "https" -> {
                        if (isExternalHost(uri.host)) { openExternal(uri); true } else false
                    }
                    "intent" -> { openIntentUri(uri.toString()); true }
                    else -> { openExternal(uri); true } // mailto:, tel:, whatsapp:, fb: ...
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                hadError = false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                refresh.isRefreshing = false
                keepSplash = false
                if (!hadError) {
                    if (url != null) lastUrl = url
                    offline.visibility = View.GONE
                    webView.visibility = View.VISIBLE
                }
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    hadError = true
                    lastUrl = request.url.toString()
                    showOffline()
                }
            }
        }
    }

    private fun setUpPush() {
        if (!PounceApplication.pushEnabled) return
        // Tapping a notification opens its "url" (set under Additional Data in OneSignal) inside the app.
        OneSignal.Notifications.addClickListener(object : INotificationClickListener {
            override fun onClick(event: INotificationClickEvent) {
                val url = event.notification.additionalData?.optString("url").orEmpty()
                val target = appUrl(Uri.parse(url)) ?: return
                runOnUiThread { load(target) }
            }
        })
        // Android 13+ asks the customer to allow notifications.
        lifecycleScope.launch { OneSignal.Notifications.requestPermission(false) }
    }

    private fun load(url: String) {
        lastUrl = url
        webView.loadUrl(url)
    }

    private fun showOffline() {
        keepSplash = false
        refresh.isRefreshing = false
        webView.visibility = View.INVISIBLE
        offline.visibility = View.VISIBLE
    }

    private fun retry() {
        offline.visibility = View.GONE
        webView.visibility = View.VISIBLE
        load(lastUrl)
    }

    /** Only pouncecompetitions.co.uk links open in the app, always in app mode. */
    private fun appUrl(uri: Uri?): String? {
        if (uri == null || uri.scheme != "https") return null
        val host = uri.host ?: return null
        if (host != SITE_HOST && host != "www.$SITE_HOST") return null
        if (uri.getQueryParameter("appmode") != null) return uri.toString()
        return uri.buildUpon().appendQueryParameter("appmode", "on").build().toString()
    }

    private fun isExternalHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return EXTERNAL_HOSTS.any { h == it || h.endsWith(".$it") }
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
        }
    }

    private fun openIntentUri(raw: String) {
        try {
            val intent = Intent.parseUri(raw, Intent.URI_INTENT_SCHEME)
            try {
                startActivity(intent)
            } catch (_: ActivityNotFoundException) {
                intent.getStringExtra("browser_fallback_url")?.let { openExternal(Uri.parse(it)) }
            }
        } catch (_: Exception) {
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        appUrl(intent.data)?.let { load(it) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush() // keeps customers logged in
    }

    companion object {
        private const val SITE_HOST = "pouncecompetitions.co.uk"

        /** These open in their own apps (Facebook, WhatsApp...) instead of inside Pounce. */
        private val EXTERNAL_HOSTS = listOf(
            "facebook.com", "fb.com", "fb.me", "m.me", "instagram.com",
            "whatsapp.com", "wa.me", "tiktok.com", "x.com", "twitter.com",
            "youtube.com", "youtu.be", "play.google.com", "apps.apple.com"
        )
    }
}
