package uk.co.pouncecompetitions.app

import android.app.Application
import com.onesignal.OneSignal

class PounceApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (pushEnabled) {
            OneSignal.initWithContext(this, BuildConfig.ONESIGNAL_APP_ID)
        }
    }

    companion object {
        /** Push only switches on once a OneSignal App ID is set in app/build.gradle.kts. */
        val pushEnabled: Boolean get() = BuildConfig.ONESIGNAL_APP_ID.isNotBlank()
    }
}
