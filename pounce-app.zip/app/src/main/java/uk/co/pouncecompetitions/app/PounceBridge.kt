package uk.co.pouncecompetitions.app

import android.webkit.JavascriptInterface
import com.onesignal.OneSignal

/**
 * Lets the website's app-mode code talk to the app, as window.PounceApp:
 *   PounceApp.isApp()                       -> true
 *   PounceApp.pushEnabled()                 -> is this phone subscribed to push
 *   PounceApp.setPushEnabled(true/false)    -> the main "Push notifications" switch
 *   PounceApp.setTopic("live_draws", true)  -> one of the topic switches
 * Topics become OneSignal tags, so you can send to e.g. everyone with live_draws = 1.
 */
class PounceBridge {

    @JavascriptInterface
    fun isApp(): Boolean = true

    @JavascriptInterface
    fun pushEnabled(): Boolean =
        PounceApplication.pushEnabled && OneSignal.User.pushSubscription.optedIn

    @JavascriptInterface
    fun setPushEnabled(on: Boolean) {
        if (!PounceApplication.pushEnabled) return
        if (on) OneSignal.User.pushSubscription.optIn() else OneSignal.User.pushSubscription.optOut()
    }

    @JavascriptInterface
    fun setTopic(topic: String, on: Boolean) {
        if (!PounceApplication.pushEnabled) return
        val key = topic.lowercase().filter { it.isLetterOrDigit() || it == '_' }.take(40)
        if (key.isEmpty()) return
        if (on) OneSignal.User.addTag(key, "1") else OneSignal.User.removeTag(key)
    }
}
