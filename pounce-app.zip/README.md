# Pounce Android app

The Pounce app opens https://pouncecompetitions.co.uk in app mode (`?appmode=on`).
It's built on GitHub, so you never need Android Studio.

## Make a new APK (from your phone)
1. Open this repository on GitHub and tap **Actions**.
2. Tap **Build Pounce APK**, then **Run workflow**.
3. Wait about 5 minutes. When the build has a green tick, open **Releases** (on the repository's main page).
4. Download `Pounce-1.0.X.apk`. That's your app.

## First time only
Before the first build, add the signing password:
**Settings → Secrets and variables → Actions → New repository secret**
- Name: `KEYSTORE_PASSWORD`
- Secret: a strong password you'll keep safe (at least 8 characters)

The first build creates the signing key (`signing/pounce.jks`) and saves it in this repository.
**Never delete it, and never lose the password.** Every future update must be signed with the same key, or phones won't install the update.
Keep this repository **private**.

## What the app does
- Loads the website in app mode. The site sees `PounceApp` in the browser's user agent.
- Black splash screen while it loads; an offline screen with TRY AGAIN when there's no connection.
- Pull down to refresh. The phone's back button goes back a page.
- Facebook, Instagram, WhatsApp, TikTok and YouTube links open in their own apps.
- Customers stay logged in. Card payments and 3-D Secure work inside the app.

## Push notifications (OneSignal)
1. Create a free OneSignal account and an Android app (it walks you through Firebase).
2. Copy the OneSignal **App ID** into `oneSignalAppId` in `app/build.gradle.kts`, then build again.
3. To make a notification open a page, add Additional Data `url` = the full page link.

The website's app-mode code can use `window.PounceApp`:
- `PounceApp.setPushEnabled(true/false)`: the main switch
- `PounceApp.setTopic("live_draws", true/false)`: topic switches (these become OneSignal tags)
- `PounceApp.pushEnabled()`

## Changing the icon
Replace `app/src/main/res/drawable/ic_launcher_foreground.xml` (a placeholder paw) with the Pounce logo.
